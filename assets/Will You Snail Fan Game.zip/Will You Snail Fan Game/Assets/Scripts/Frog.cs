using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Frog : MonoBehaviour
{
    public Rigidbody2D rb;

    [Header("Sprites")]
    public SpriteRenderer sr;
    public Sprite idleSprite, jumpSprite;

    [Header("Ground Check")]
    public bool isGrounded;
    public Transform groundCheck;
    public float checkRadius;
    public LayerMask groundMask;
    [Header("Wall Check")]
    public bool isWall;
    public Transform wallCheck;

    [Header("Floor Check")] 
    public bool isFloor;
    public Transform floorCheck;

    [Header("Jumping")]
    public float jumpCooldown;
    public float jumpCooldownNumber;
    public float jumpForce;
    public float sidewaysForce;

    void Awake()
    {
        sidewaysForce = jumpForce * 0.17f;
        jumpCooldown = jumpCooldownNumber;
    }

    void Update()
    {
        isGrounded = Physics2D.OverlapCircle(groundCheck.position, checkRadius, groundMask);
        isWall = Physics2D.OverlapCircle(wallCheck.position, checkRadius, groundMask);
        isFloor = Physics2D.OverlapCircle(floorCheck.position, checkRadius, groundMask);
        if (isGrounded)
        {
            jumpCooldown -= Time.deltaTime;
        }
        if(isWall)
        {
            Flip();
        }
        if (isFloor == false && isGrounded)
        {
            Flip();
        }
        if (!isGrounded)
        {
            sr.sprite = jumpSprite;
        }
        else
        {
            sr.sprite = idleSprite;
        }
    }

    void FixedUpdate()
    {
        if(jumpCooldown <= 0)
        {
            rb.AddForce(new Vector2(sidewaysForce, jumpForce), ForceMode2D.Impulse);
            jumpCooldown = jumpCooldownNumber;
        }
    }

    void Flip()
    {
        sidewaysForce *= -1;
        transform.localScale = new Vector2(transform.localScale.x * -1, transform.localScale.y);
    }
}
