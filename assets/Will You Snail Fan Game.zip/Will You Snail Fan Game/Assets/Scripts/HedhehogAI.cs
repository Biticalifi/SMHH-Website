using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HedhehogAI : MonoBehaviour
{
    public Rigidbody2D rb;
    public float speed;
    public bool isFacingRight;
    public Animator anim;

    [Header("Ground Check")]
    public bool isGrounded;
    public Transform groundCheck;
    public float checkRadius;
    public LayerMask groundMask;

    [Header("Wall Check")]
    public bool isWall;
    public Transform wallCheck;

    [Header("Player Check")]
    public bool isPlayered;
    public float playerRadius;
    public LayerMask playerMask;
    public Transform player;

    [Header("Dash")]
    public float dashTimer;
    public bool isDashing;

    public void Awake()
    {
        dashTimer = 1;
        isFacingRight = true;
    }

    void Update()
    {
        isGrounded = Physics2D.OverlapCircle(groundCheck.position, checkRadius, groundMask);
        isWall = Physics2D.OverlapCircle(wallCheck.position, checkRadius, groundMask);
        isPlayered = Physics2D.OverlapCircle(transform.position, playerRadius, playerMask) && player.position.y - transform.position.y < 1.1f && player.position.y - transform.position.y > -1.1f;
        if (isGrounded && !isDashing)
        {
            Flip();
            Debug.Log("Air Flip");
        }
        if (isWall && !isDashing)
        {
            Flip();
        }
        if (!isPlayered)
        {
            if (!isDashing)
            {
                dashTimer = 0.7f;
                anim.SetBool("isPlayered", false);
            }
            if (isFacingRight && dashTimer <= 0)
            {
                speed = 0.75f;
            }
            else if (!isFacingRight && dashTimer <= 0)
            {
                speed = -0.75f;
            }
        }
        if (isPlayered)
        {
            isDashing = true;
            if(dashTimer > 0)
            {
                speed = 0;
            }
            else if (dashTimer < 0 && isFacingRight)
            {
                speed = 0.75f;
            }
            else if(dashTimer < 0 && !isFacingRight)
            {
                speed = -0.75f;
            }
            if(player.position.x > transform.position.x && dashTimer > 0 && !isFacingRight)
            {
                Flip();
            }
            else if(player.position.x < transform.position.x && dashTimer > 0 && isFacingRight)
            {
                Flip();
            }
        }
        if(isDashing == true)
            {
                dashTimer -= Time.deltaTime;
                anim.SetBool("isPlayered", true);
            }
    }

    void FixedUpdate()
    {
        rb.velocity = new Vector2(speed, rb.velocity.y);
        if(dashTimer <= 0)
        {
            rb.AddForce(new Vector2(speed * 1200, 0), ForceMode2D.Impulse);
        }
        if(dashTimer <= -1.2f)
        {
            dashTimer = 0.7f;
            isDashing = false;
            Flip();
        }
    }

    void Flip()
    {
        speed *= -1;
        isFacingRight = !isFacingRight;
        transform.localScale = new Vector2(transform.localScale.x * -1, transform.localScale.y);
    }
}
