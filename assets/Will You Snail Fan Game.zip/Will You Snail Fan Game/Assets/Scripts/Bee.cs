using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bee : MonoBehaviour
{
    public Transform topPosition;
    public Transform bottomPosition;
    float position;
    public float speed;

    void Awake()
    {
        position = 1;
    }

    void FixedUpdate()
    {
        if(position == 1)
        {
            transform.position = Vector2.MoveTowards(transform.position, topPosition.position, speed);
        }
        else if(position == 2)
        {
            transform.position = Vector2.MoveTowards(transform.position, bottomPosition.position, speed);
        }
        if(topPosition.position.y - transform.position.y < 0.01f)
        {
            position = 2;
        }
        if(transform.position.y - bottomPosition.position.y < 0.01f)
        {
            position = 1;
        }
    }
}
