using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Turret : MonoBehaviour
{
    public Animator anim;
    public float shootCooldown;
    public GameObject ball;
    GameObject newBall;
    GameObject[] newBalls;

    void Update()
    {
        newBalls = GameObject.FindGameObjectsWithTag("Ball");
        shootCooldown -= Time.deltaTime;
        if(shootCooldown <= 0)
        {
            newBall = Instantiate(ball);
            newBall.gameObject.SetActive(true);
            newBall.transform.position = transform.position;
            shootCooldown = 2.7f;
            anim.SetBool("isReloading", true);
        }
        foreach(GameObject Ball in newBalls)
        {
            TurretBall staticVar = Ball.gameObject.GetComponent<TurretBall>();
            if(staticVar != null)
            {
                if (staticVar.isInPlayer)
                {
                    Destroy(Ball);
                }
            }
        }
        if(shootCooldown > 0 && shootCooldown < 2.65f)
        {
            anim.SetBool("isReloading", false);
        }
    }

}
