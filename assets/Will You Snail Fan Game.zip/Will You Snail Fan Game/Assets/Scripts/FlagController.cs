using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlagController : MonoBehaviour
{
    public Animator anim;
    public bool currentLevelFinished;
    public int currentLevel;

    void Start()
    {
        currentLevelFinished = false;
    }

    void Update()
    {
        if (currentLevelFinished)
        {
            anim.SetBool("levelFinished", true);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.gameObject.tag == "Player")
        {
            currentLevelFinished = true;
        }
    }
}
