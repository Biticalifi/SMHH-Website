using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlueButtonPress : MonoBehaviour
{
    public SpriteRenderer sr;
    public Sprite notPressed;
    public Sprite pressed;
    public TilesManager script;

    void Update()
    {
        if (script.blueActive)
        {
            sr.sprite = pressed;
        }
        else
        {
            sr.sprite = notPressed;
        }
    }
}
