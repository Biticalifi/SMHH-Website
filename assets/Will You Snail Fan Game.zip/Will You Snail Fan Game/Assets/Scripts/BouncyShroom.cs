using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BouncyShroom : MonoBehaviour
{
    public Animator anim;
    public PlayerController pc;

    void Update()
    {
        if(pc.isBounced == true)
        {
            anim.SetBool("isBouncy", true);
        }
        if(pc.isBounced == false)
        {
            anim.SetBool("isBouncy", false);
        }
    }
}
