using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TurretBall : MonoBehaviour
{
    public float speed;
    public Rigidbody2D rb;
    public bool isInPlayer;

    void FixedUpdate()
    {
        rb.velocity = new Vector2(speed, 0);
    }

    void OnCollisionEnter2D(Collision2D other)
    {
        if(other.gameObject.tag != "Player")
        {
            isInPlayer = true;
        }
    }

    void OnCollisionExit2D(Collision2D collision)
    {
        isInPlayer = false;
    }
}
