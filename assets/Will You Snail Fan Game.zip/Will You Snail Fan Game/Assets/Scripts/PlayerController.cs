using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public Rigidbody2D rb;
    public Animator animator;

    public float speed;
    public float jumpForce;

    [Header("Jumping")]
    public int extraJumpValue;
    private int extraJumps;
    public float jumpTimeCounter;
    public float jumpTimeValue;
    public float groundedRemember;
    public float groundedRememberTime;

    [Header("Direction")]
    public bool isFacingRight;
    private Vector3 scaler;

    [Header("Grounded")]
    public bool isGrounded;
    public Transform groundCheck;
    public float checkRadius;
    public LayerMask groundMask;
    public LayerMask turretMask;

    [Header("Bounced")]
    public bool isBounced;
    public float bounceRadius;
    public LayerMask bounceMask;

    [Header("Buttons")]
    public TilesManager tileScript;
    public bool onBlueButton;
    public LayerMask blueMask;
    public bool onRedButton;
    public LayerMask redMask;

    [Header("Magnetic")]
    public bool isOnMagnet;
    public bool isUnderMagnet;
    public float magnetRange;
    public LayerMask magnetMask;

    void Start()
    {
        extraJumps = extraJumpValue;
    }

    private void FixedUpdate()
    {
        isGrounded = Physics2D.OverlapCircle(groundCheck.position, checkRadius, groundMask) || Physics2D.OverlapCircle(groundCheck.position, checkRadius, turretMask);
        isBounced = Physics2D.OverlapCircle(groundCheck.position, bounceRadius, bounceMask);
        onBlueButton = Physics2D.OverlapCircle(groundCheck.position, checkRadius, blueMask);
        onRedButton = Physics2D.OverlapCircle(groundCheck.position, checkRadius, redMask);
        isOnMagnet = Physics2D.Raycast(transform.position, Vector2.down, magnetRange, magnetMask) || Physics2D.OverlapCircle(groundCheck.position, checkRadius, magnetMask);
        isUnderMagnet = Physics2D.Raycast(transform.position, Vector2.up, magnetRange * 0.75f, magnetMask);

        TilesActive();

        if (Input.GetKey("d") || Input.GetKey("right"))
        {
            rb.velocity = new Vector2(speed, rb.velocity.y);
            isFacingRight = true;
        }

        if (Input.GetKey("a") || Input.GetKey("left"))
        {
            rb.velocity = new Vector2(-speed, rb.velocity.y);
            isFacingRight = false;
        }

        if (!Input.GetKey("d") && !Input.GetKey("right") && !Input.GetKey("a") && !Input.GetKey("left"))
        {
            rb.velocity = new Vector2(0, rb.velocity.y);
        }
        if ((Input.GetKey("d") || Input.GetKey("right")) && (Input.GetKey("a") || Input.GetKey("left")))
        {
            rb.velocity = new Vector2(0, rb.velocity.y);
        }

        if (isFacingRight == true)
        {
            scaler = transform.localScale;
            scaler.x = 1;
            transform.localScale = scaler;
        }
        else if (isFacingRight == false)
        {
            scaler = transform.localScale;
            scaler.x = -1;
            transform.localScale = scaler;
        }
    }

    private void Update()
    {
        Animate();
        if (groundedRemember > 0 == true)
        {
            extraJumps = extraJumpValue;
        }

        groundedRemember -= Time.deltaTime;
        if (isGrounded || isBounced || isOnMagnet || isUnderMagnet)
        {
            groundedRemember = groundedRememberTime;
        }

        if ((Input.GetKeyDown("w") || Input.GetKeyDown("up") || Input.GetKeyDown("space")) && extraJumps > 0)
        {
            rb.velocity = Vector2.up * jumpForce;
            extraJumps--;
            jumpTimeCounter = jumpTimeValue;
        }
        else if ((Input.GetKeyDown("w") || Input.GetKeyDown("up") || Input.GetKeyDown("space")) && extraJumps == 0 && groundedRemember > 0)
        {
            rb.velocity = Vector2.up * jumpForce;
            jumpTimeCounter = jumpTimeValue;
        }
        if (Input.GetKey("w") || Input.GetKey("up") || Input.GetKey("space"))
        {
            if(jumpTimeCounter > 0)
            {
                rb.velocity = Vector2.up * jumpForce;
                jumpTimeCounter -= Time.deltaTime;
            }
        }
        if (!Input.GetKey("w") && !Input.GetKey("up") && !Input.GetKey("space"))
        {
            jumpTimeCounter = 0;
        }
        if (isBounced)
        {
            rb.velocity = Vector2.up * jumpForce * 2.3f;
        }
        if (isOnMagnet && !isGrounded)
        {
            rb.velocity = new Vector2(rb.velocity.x, -10);
        }
        if (isUnderMagnet)
        {
            rb.velocity = new Vector2(rb.velocity.x, 10);
        }
    }

    void Respawn()
    {
        transform.position = new Vector3(0, 0, -6);
        rb.velocity = new Vector2(0, 0);
    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.tag == "Spike" || other.gameObject.tag == "Ball")
        {
            Respawn();
        }
    }

    void Animate()
    {
        animator.SetFloat("Speed", Mathf.Abs(rb.velocity.x));
        if(Input.GetKey("w") || Input.GetKey("up") || Input.GetKey("space"))
        {
            animator.SetBool("isJumping", true);
        }
        if((isGrounded || isOnMagnet) && rb.velocity.y < 0.01)
        {
            animator.SetBool("isJumping", false);
        }
    }

    void TilesActive()
    {
        if (onBlueButton)
        {
            tileScript.ActivateBlue();
        }
        if (onRedButton)
        {
            tileScript.ActivateRed();
        }
    }
}
