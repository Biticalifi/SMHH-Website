using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Parallax : MonoBehaviour
{
    float lenght, startpos;
    public GameObject player;
    public float parallaxValue;


    void Start()
    {
        startpos = transform.position.x;
        lenght = GetComponent<SpriteRenderer>().bounds.size.x;
    }
    void Update()
    {
        float temp = (player.transform.position.x * (1f - parallaxValue));
        float dist = (player.transform.position.x * parallaxValue);
        transform.position = new Vector3(startpos + dist, transform.position.y, transform.position.z);

        if(temp > startpos + (0.7f * lenght))
        {
            startpos += lenght;
        }
        else if(temp < startpos - (0.7f * lenght))
        {
            startpos -= lenght;
        }
    }
}
