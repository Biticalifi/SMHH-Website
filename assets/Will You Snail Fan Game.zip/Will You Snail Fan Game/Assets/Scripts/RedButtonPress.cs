using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RedButtonPress : MonoBehaviour
{
    public SpriteRenderer sr;
    public Sprite notPressed;
    public Sprite pressed;
    public TilesManager script;

    void Update()
    {
        if (script.redActive)
        {
            sr.sprite = pressed;
        }
        else
        {
            sr.sprite = notPressed;
        }
    }
}
