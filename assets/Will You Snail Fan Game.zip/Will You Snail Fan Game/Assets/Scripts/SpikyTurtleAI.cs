using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpikyTurtleAI : MonoBehaviour
{
    public Rigidbody2D rb;
    public float speed;

    [Header("Ground Check")]
    public bool isGrounded;
    public Transform groundCheck;
    public float checkRadius;
    public LayerMask groundMask;

    [Header("Wall Check")]
    public bool isWall;
    public Transform wallCheck;

    void Update()
    {
        isGrounded = Physics2D.OverlapCircle(groundCheck.position, checkRadius, groundMask);
        isWall = Physics2D.OverlapCircle(wallCheck.position, checkRadius, groundMask);
        if (isGrounded)
        {
            Flip();
        }
        if(isWall)
        {
            Flip();
        }
    }

    void FixedUpdate()
    {
        rb.velocity = new Vector2(speed, rb.velocity.y);
    }

    void Flip()
    {
        speed *= -1;
        transform.localScale = new Vector2(transform.localScale.x * -1, transform.localScale.y);
    }
}
