using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TilesManager : MonoBehaviour
{
    public bool blueActive;
    float blueActiveTime;
    public GameObject blueTiles;
    public bool redActive;
    float redActiveTime;
    public GameObject redTiles;
    public float activeTimeStart;

    void Update()
    {
        blueActiveTime -= Time.deltaTime;
        redActiveTime -= Time.deltaTime;
        if (blueActive)
        {
            blueTiles.SetActive(true);
        }
        if (!blueActive)
        {
            blueTiles.SetActive(false);
        }
        if (redActive)
        {
            redTiles.SetActive(true);
        }
        if (!redActive)
        {
            redTiles.SetActive(false);
        }

        if(blueActiveTime > 0)
        {
            blueActive = true;
        }
        else
        {
            blueActive = false;
        }
        if (redActiveTime > 0)
        {
            redActive = true;
        }
        else
        {
            redActive = false;
        }
    }

    public void ActivateBlue()
    {
        if(blueActiveTime <= 0)
        {
            blueActiveTime = activeTimeStart;
        }
    }
    public void ActivateRed()
    {
        if (redActiveTime <= 0)
        {
            redActiveTime = activeTimeStart;
        }
    }
}
