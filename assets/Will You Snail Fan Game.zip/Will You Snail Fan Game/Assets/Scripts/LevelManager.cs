using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class LevelManager : MonoBehaviour
{
    [Header("Level Icons")]
    public Button one2;
    public Button one3;
    public Button one4;
    public Button one5;
    public Button one6;
    public Button one7;
    public Button one8;
    public Button one9;
    public Button one10;

    [Header("Levels")]
    public FlagController script;
    public static int bestLevelBeaten;

    void Update()
    {
        if(SceneManager.GetActiveScene().buildIndex == 0)
        {
            UpdateWorldOneIcons();
        }
        if (script.currentLevelFinished == true)
        {
            if(script.currentLevel > bestLevelBeaten)
            {
                bestLevelBeaten = script.currentLevel;
            }
        }
        if (Input.GetKey("space"))
        {
            SceneManager.LoadScene(0);
        }
    }

    void UpdateWorldOneIcons()
    {
        if (bestLevelBeaten < 1)
        {
            one2.interactable = false;
        }
        else if (bestLevelBeaten >= 1)
        {
            one2.interactable = true;
        }
        if (bestLevelBeaten < 2)
        {
            one3.interactable = false;
        }
        else if (bestLevelBeaten >= 2)
        {
            one3.interactable = true;
        }
        if (bestLevelBeaten < 3)
        {
            one4.interactable = false;
        }
        else if (bestLevelBeaten >= 3)
        {
            one4.interactable = true;
        }
        if (bestLevelBeaten < 4)
        {
            one5.interactable = false;
        }
        else if (bestLevelBeaten >= 4)
        {
            one5.interactable = true;
        }
        if (bestLevelBeaten < 5)
        {
            one6.interactable = false;
        }
        else if (bestLevelBeaten >= 5)
        {
            one6.interactable = true;
        }
        if (bestLevelBeaten < 6)
        {
            one7.interactable = false;
        }
        else if (bestLevelBeaten >= 6)
        {
            one7.interactable = true;
        }
        if (bestLevelBeaten < 7)
        {
            one8.interactable = false;
        }
        else if (bestLevelBeaten >= 7)
        {
            one8.interactable = true;
        }
        if (bestLevelBeaten < 8)
        {
            one9.interactable = false;
        }
        else if (bestLevelBeaten >= 8)
        {
            one9.interactable = true;
        }
        if (bestLevelBeaten < 9)
        {
            one10.interactable = false;
        }
        else if (bestLevelBeaten >= 9)
        {
            one10.interactable = true;
        }
    }

    public void Level1()
    {
        SceneManager.LoadScene(1);
    }
}
